﻿using System;
class Program
{
    static void Main(){
        Console.WriteLine("Ingrese el ejercicio a entrar");
        Console.WriteLine("1. Ejercicio edades");
        Console.WriteLine("2. Ejercicio calificación");
        Console.WriteLine("2. Ejercicio tarifa de transporte");
        int op = int.Parse(Console.ReadLine());

        switch (op){
            case 1:
                Console.WriteLine("Ingrese su edad porfavor");
                int edad = int.Parse(Console.ReadLine());
                if (edad >= 65){
                    Console.WriteLine("Usted es un adulto mayor");
                }
                else if(edad>= 18 && edad <= 64){
                        Console.WriteLine("Usted es un adulto");
                }
                else if(edad>= 12 && edad <= 17){
                        Console.WriteLine("Usted es un adolescente");
                }
                else if(edad < 12){
                        Console.WriteLine("Usted es un Niño");
                }
            break;

            case 2:
                Console.WriteLine("Ingrese su calificación");
                int cali = int.Parse(Console.ReadLine());
                if (cali >= 90){
                    Console.WriteLine("Excelente");
                }
                else if(cali>= 80 && cali <= 89){
                        Console.WriteLine("Notable");
                }
                else if(cali>= 79 && cali <= 60){
                        Console.WriteLine("Aprobado");
                }
                else if(cali <= 59){
                        Console.WriteLine("Reprobado");
                }
            break;

            case 3:
                Console.WriteLine("Seleccione su categoria");
                Console.WriteLine("1. Adulto");
                Console.WriteLine("2. Estudiante");
                Console.WriteLine("3. Adulto mayor");
                Console.WriteLine("4. Niño");
                Console.WriteLine("5. Salir del programa");
                int tarifa = 10;
                int opc = int.Parse(Console.ReadLine());  
                
                switch (opc){
                    case 1:
                        Console.WriteLine("Usted debe pagar " + tarifa);
                    break;
                    case 2:
                        tarifa=tarifa/2;
                        Console.WriteLine("Usted debe pagar " + tarifa);
                    break;
                    case 3:
                        double tariAM = tarifa*0.70;
                        Console.WriteLine("Usted debe pagar " + tariAM);
                    break;
                    case 4:
                        Console.WriteLine("Cuantos años tiene su niño?");
                        int edadN= int.Parse(Console.ReadLine());
                        if(edadN>0 && edadN<5){
                            Console.WriteLine("Su tarifa es gratis");
                        }
                        else if (edadN>=5 && edadN<=12){
                            tarifa=tarifa/2;
                            Console.WriteLine("Su tarfica de pago es "+tarifa);
                        }
                    break;
                    case 5:
                        Console.WriteLine("Feliz dia");
                        Environment.Exit(0);
                    break;
                }
            break;
        }
    }    
}
