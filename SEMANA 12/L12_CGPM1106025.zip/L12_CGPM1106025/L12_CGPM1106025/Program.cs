﻿using System;

class Program
{
    static void Main()
/* Ejercicio 1:   {
        Console.Write("Ingresa una palabra: ");
        string palabra = Console.ReadLine();

        string invertida = "";
        for (int i = palabra.Length - 1; i >= 0; i--)
        {
            invertida += palabra[i];
        }

        Console.WriteLine("Palabra invertida: " + invertida);

        // Verificar si es un palíndromo
        if (palabra.ToLower() == invertida.ToLower())
        {
            Console.WriteLine("Es un palíndromo.");
        }
        else
        {
            Console.WriteLine("No es un palíndromo.");
        }
    }
}
*/

   
  /* Ejercicio 2 
    {
        Console.Write("Ingresa una frase: ");
        string frase = Console.ReadLine().ToLower();

        
        int contadorA = 0;
        int contadorE = 0;
        int contadorI = 0;
        int contadorO = 0;
        int contadorU = 0;

        foreach (char letra in frase)
        {
            if (letra == 'a') contadorA++;
            else if (letra == 'e') contadorE++;
            else if (letra == 'i') contadorI++;
            else if (letra == 'o') contadorO++;
            else if (letra == 'u') contadorU++;
        }

        Console.WriteLine("Conteo de vocales:");
        Console.WriteLine("a: " + contadorA);
        Console.WriteLine("e: " + contadorE);
        Console.WriteLine("i: " + contadorI);
        Console.WriteLine("o: " + contadorO);
        Console.WriteLine("u: " + contadorU);
    }
}

*/


    {
        Console.Write("Ingresa una frase: ");
        string frase = Console.ReadLine();

        Console.Write("Carácter o palabra a reemplazar: ");
        string original = Console.ReadLine();

        Console.Write("Nuevo carácter o palabra: ");
        string nuevo = Console.ReadLine();

        string modificada = frase.Replace(original, nuevo);

        Console.WriteLine("Frase modificada: " + modificada);
    }
}
