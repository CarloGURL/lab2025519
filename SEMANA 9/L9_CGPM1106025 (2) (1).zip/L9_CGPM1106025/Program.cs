﻿// See https://aka.ms/new-console-template for more information
using System;
class Program {
 static void Main() {
    //ejercicio 1
    Console.WriteLine("Ingrese el monto de la compra");
    int num = int.Parse(Console.ReadLine());
    double precio =0 ;
    if (num > 100) 
    {
        precio = num * 0.80 ;
        Console.WriteLine("Usted obtuvo un descuento debe pagar es: " + precio);
    }
    if (num <= 50 && num >= 99)
    {
        precio = num * 0.90;
        Console.WriteLine("Usted obtuvo un descuento debe pagar es: " + precio);
    }
    if (num < 50 )
    {
        precio = num;
        Console.WriteLine("La cantidad que debe pagar es: " + precio);
    }


    //Ejercicio 2
    Console.WriteLine("Bienvenido al club \r\n Porfavor Ingrese su edad");
    int edad = int.Parse(Console.ReadLine());
    if (edad < 18 )
    {
        Console.WriteLine("Acceso Denegado :v");
    }

    //Ejercicio 3
    Console.WriteLine("Ingresa el primer numero");
    int n1= int.Parse(Console.ReadLine());
    int n2= int.Parse(Console.ReadLine());
    int ope= 0;
    if(n1 == n2)
    {
        ope=n1*n2;
    }
    if(n1 > n2)
    {
        ope= n1-n2;
    }
    else{
        ope= n1+n2;
    }

    Console.WriteLine("La operacion resultante es" + ope);


    //ejercicio 4
    Console.WriteLine("Ingrese el nombre del vendedor");
    string nom= Console.ReadLine();
    Console.WriteLine("ingresa la cantidad de autos vendidos al mes");
    int ncarros= int.Parse(Console.ReadLine());
    int sueldo = ncarros *335;
    double sueldone= sueldo *0.95;
    double impuesto= sueldo * 0.05;

    Console.WriteLine("El nombre del vendedor es: " + nom + "\r\n el sueldo bruto es: "+ sueldo + "\r\n El impuesto es: "+ impuesto+ "\r\n El sueldo neto es: " + sueldone);

 }
}
