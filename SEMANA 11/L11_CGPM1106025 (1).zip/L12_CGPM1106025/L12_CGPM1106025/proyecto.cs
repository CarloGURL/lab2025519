/*using System;

class Program
{
    static void Main()  //Ejercicio 1
    {
        int suma = 0;
        int contador = 0;
        while (suma < 100)
        {
            Console.Write("Ingrese un número");
            int num = int.Parse(Console.ReadLine());
            suma += num;
            contador++;
        }
        Console.WriteLine($"Suma total: {suma}");
        Console.WriteLine($"Cantidad de números ingresados: {contador}");
    }
}
*/
//Ejercicio 2
/*
using System;

class Program
{
    static void Main()
    {
        Console.Write("Ingrese un número para ver su tabla de multiplicar");
        int num = int.Parse(Console.ReadLine());

        for (int i = 1; i <= 10; i++)
        {
            int mul = i*num;
            Console.WriteLine(num + "x" + i + "=" +mul);
        }
    }
} */

/*Ejercicio 3
using System;

class Program
{
    static void Main()
    {
        Random random = new Random();
        int Secreto = random.Next(1, 51);
        int oportunidad;

        do
        {
            Console.Write("Adivina el número entre 1 y 50: ");
            oportunidad = int.Parse(Console.ReadLine());

            if (oportunidad < Secreto)
                Console.WriteLine("El número es mayor. Intenta de nuevo.");
            else if (oportunidad > Secreto)
                Console.WriteLine("El número es menor. Intenta de nuevo.");
        }
        while (oportunidad != Secreto);

        Console.WriteLine("Adivinaste el número :v");
    }
}
*/

/*Ejercicio4
using System;

class Program
{
    static void Main()
    {
        Console.Write("Ingrese el número de filas del triángulo: ");
        int n = int.Parse(Console.ReadLine());

        int i = 1;
        while (i <= n)
        {
            for (int j = 0; j < i; j++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
            i++;
        }
    }
}
*/