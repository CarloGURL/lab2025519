﻿using System;

class Program

{ /*
    static void Main()
    {
        int[] vector = new int[100]; // Tamaño máximo del vector
        int count = 0; // Cantidad actual de elementos en el vector
        int opcion;

        do
        {
            Console.WriteLine("\nMenú:");
            Console.WriteLine("1. Introducir valores.");
            Console.WriteLine("2. Leer datos.");
            Console.WriteLine("3. Desplegar los datos.");
            Console.WriteLine("4. Buscar un dato.");
            Console.WriteLine("5. Actualizar un dato.");
            Console.WriteLine("6. Ordenar los valores.");
            Console.WriteLine("7. Salir.");
            Console.Write("Elija una opción: ");
            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1: // Introducir valores
                    Console.Write("¿Cuántos valores desea ingresar? ");
                    count = int.Parse(Console.ReadLine());
                    for (int i = 0; i < count; i++)
                    {
                        Console.Write($"Ingrese el valor en la posición {i}: ");
                        vector[i] = int.Parse(Console.ReadLine());
                    }
                    break;

                case 2: // Leer los datos
                    Console.WriteLine($"El vector tiene {count} elementos.");
                    break;

                case 3: // Desplegar los datos
                    Console.WriteLine("Valores en el vector:");
                    for (int i = 0; i < count; i++)
                    {
                        Console.WriteLine($"Posición {i}: {vector[i]}");
                    }
                    break;

                case 4: // Buscar un dato
                    Console.Write("Ingrese el número a buscar: ");
                    int buscar = int.Parse(Console.ReadLine());
                    bool encontrado = false;
                    for (int i = 0; i < count; i++)
                    {
                        if (vector[i] == buscar)
                        {
                            Console.WriteLine($"Número encontrado en la posición {i}.");
                            encontrado = true;
                            break;
                        }
                    }
                    if (!encontrado) Console.WriteLine("Número no encontrado.");
                    break;

                case 5: // Actualizar un dato
                    Console.Write("Ingrese la posición a actualizar: ");
                    int posicion = int.Parse(Console.ReadLine());
                    if (posicion >= 0 && posicion < count)
                    {
                        Console.Write("Ingrese el nuevo valor: ");
                        vector[posicion] = int.Parse(Console.ReadLine());
                        Console.WriteLine("Dato actualizado.");
                    }
                    else
                    {
                        Console.WriteLine("Posición inválida.");
                    }
                    break;

                case 6: // Ordenar los valores
                    for (int i = 0; i < count - 1; i++)
                    {
                        for (int j = i + 1; j < count; j++)
                        {
                            if (vector[i] > vector[j])
                            {
                                int temp = vector[i];
                                vector[i] = vector[j];
                                vector[j] = temp;
                            }
                        }
                    }
                    Console.WriteLine("Valores ordenados.");
                    break;

                case 7: // Salir
                    Console.WriteLine("ADIOOOS :V");
                    break;

                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }
        } while (opcion != 7);
    }
}
*/

struct Producto
{
    public string Nombre;
    public string Codigo;
    public float Precio;
    public int Cantidad;
}

class Inventario
{
    static void Main()
    {
        Producto[] inventario = new Producto[100];
        int count = 0;
        int opcion;

        do
        {
            Console.WriteLine("\nMenú:");
            Console.WriteLine("1. Agregar producto.");
            Console.WriteLine("2. Modificar precio de un producto.");
            Console.WriteLine("3. Mostrar productos.");
            Console.WriteLine("4. Calcular valor total del inventario.");
            Console.WriteLine("5. Salir.");
            Console.Write("Elija una opción: ");
            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1: // Agregar producto
                    Console.Write("Nombre del producto: ");
                    inventario[count].Nombre = Console.ReadLine();
                    Console.Write("Código del producto: ");
                    inventario[count].Codigo = Console.ReadLine();
                    Console.Write("Precio del producto: ");
                    inventario[count].Precio = float.Parse(Console.ReadLine());
                    Console.Write("Cantidad del producto: ");
                    inventario[count].Cantidad = int.Parse(Console.ReadLine());
                    count++;
                    Console.WriteLine("Producto agregado.");
                    break;

                case 2: // Modificar precio de un producto
                    Console.Write("Ingrese el código del producto: ");
                    string codigo = Console.ReadLine();
                    bool encontrado = false;
                    for (int i = 0; i < count; i++)
                    {
                        if (inventario[i].Codigo == codigo)
                        {
                            Console.Write("Ingrese el nuevo precio: ");
                            inventario[i].Precio = float.Parse(Console.ReadLine());
                            Console.WriteLine("Precio modificado.");
                            encontrado = true;
                            break;
                        }
                    }
                    if (!encontrado) Console.WriteLine("Producto no encontrado.");
                    break;

                case 3: // Mostrar productos
                    Console.WriteLine("Productos en el inventario:");
                    for (int i = 0; i < count; i++)
                    {
                        Console.WriteLine($"Nombre: {inventario[i].Nombre}, Código: {inventario[i].Codigo}, Precio: {inventario[i].Precio}, Cantidad: {inventario[i].Cantidad}");
                    }
                    break;

                case 4: // Calcular valor total del inventario
                    float total = 0;
                    for (int i = 0; i < count; i++)
                    {
                        total += inventario[i].Precio * inventario[i].Cantidad;
                    }
                    Console.WriteLine($"El valor total del inventario es: {total}");
                    break;

                case 5: // Salir
                    Console.WriteLine("¡Saliendo del programa!");
                    break;

                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }
        } while (opcion != 5);
    }
}
}
