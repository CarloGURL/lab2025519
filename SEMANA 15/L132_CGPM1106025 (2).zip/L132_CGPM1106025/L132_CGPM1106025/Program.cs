﻿using System;

class Program
{ /*Ejercicio 1 
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su número de DNI (solo números):");
        int dni = int.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese la letra de su DNI (solo un carácter):");
        char letra = Convert.ToChar(Console.Read()); // Tomar directamente un carácter sin usar cadenas

        if (CompruebaLetraDNI(dni, letra))
        {
            Console.WriteLine("Bienvenido");
        }
        else
        {
            Console.WriteLine("Ha cometido Ud. un error");
        }
    }

    static char LetraDNI(int dni)
    {
        string letras = "TRWAGMYFPDXBNJZSQVHLCKE";
        return letras[dni % 23];
    }

    static bool CompruebaLetraDNI(int dni, char letra)
    {
        return LetraDNI(dni) == letra;
    }
}

 


/*EJERCICIO 2

    static void Main(string[] args)
    {
        // Contraseña correcta en caso de que se quiera utilizar: 
        string contraseñaCorrecta = "CEBOLLAS75";
        
        SolicitarContraseña(contraseñaCorrecta);
    }

    static void SolicitarContraseña(string contraseñaCorrecta)
    {
        int intentos = 0;

        while (intentos < 3)
        {
            Console.WriteLine("Ingrese su contraseña:");
            string entrada = Console.ReadLine();

            if (ValidarFormato(entrada) && entrada == contraseñaCorrecta)
            {
                Console.WriteLine("Acceso permitido");
                return;
            }

            intentos++;
            Console.WriteLine("Contraseña incorrecta. Intentos restantes: " + (3 - intentos));
        }

        Console.WriteLine("Acceso denegado");
    }

    static bool ValidarFormato(string contraseña)
    {
        // Validar formato de la contraseña:
        return contraseña.Length >= 8 && 
               contraseña.Any(char.IsUpper) &&
               contraseña.Any(char.IsDigit);
    }
}

Quitar esto xd*/


    
static void MostrarMenu()
    {
        Console.WriteLine("CAJERO AUTOMÁTICO :V");
        Console.WriteLine("1. Consultar saldo");
        Console.WriteLine("2. Retirar dinero");
        Console.WriteLine("3. Depositar dinero");
        Console.WriteLine("4. Salir");
        Console.Write("Elige una opción: ");
    }

    static double ConsultarSaldo(double saldo)
    {
        Console.WriteLine($"Tu saldo actual es: {saldo}");
        return saldo;
    }

    static double Depositar(double saldo, double cantidad)
    {
        if (cantidad > 0)
        {
            saldo += cantidad;
            Console.WriteLine($"Has depositado {cantidad}. Nuevo saldo: {saldo}");
        }
        else
        {
            Console.WriteLine("Cantidad no válida");
        }
        return saldo;
    }

    static double Retirar(double saldo, double cantidad)
    {
        if (cantidad > 0 && cantidad <= saldo)
        {
            saldo -= cantidad;
            Console.WriteLine($"Has retirado {cantidad}. Nuevo saldo: {saldo}");
        }
        else
        {
            Console.WriteLine("Cantidad no válida o saldo insuficiente");
        }
        return saldo;
    }

    static void Main()
    {
        double saldo = 1000;
        bool salir = false;
        
        while (!salir)
        {
            MostrarMenu();
            string opcion = Console.ReadLine();
            
            switch (opcion)
            {
                case "1":
                    ConsultarSaldo(saldo);
                    break;
                case "2":
                    Console.Write("Introduce cantidad a retirar: ");
                    double retiro = double.Parse(Console.ReadLine());
                    saldo = Retirar(saldo, retiro);
                    break;
                case "3":
                    Console.Write("Introduce cantidad a depositar: ");
                    double deposito = double.Parse(Console.ReadLine());
                  saldo = Depositar(saldo, deposito);
                    break;
                case "4":
                    salir = true;
                    break;
                default:
                    Console.WriteLine("Opción no válida");
                    break;
            }
        }
    }
}
