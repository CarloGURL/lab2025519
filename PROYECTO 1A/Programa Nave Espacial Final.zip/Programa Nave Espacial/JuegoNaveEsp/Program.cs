﻿using System.ComponentModel.DataAnnotations;

class Program
{
    
    static void Main()
    {
        //Declaras variables
        bool valido = false;
        int valor = 0;
        int combustible = 30;
        int oxigeno = 50;
        int suministros = 40;
        int integridadNv = 100;
        int dias = 1; 
        Random random = new Random();
        int razon = 0;
        //Bienvenida
        Console.WriteLine("Bienvenido Capitan Tadeus, estas a punto de adentrarte a un viaje intergalactico. Comenzemos primero dandote unas pequeñas instrucciones:");
        Console.WriteLine("En tu viaje deberas gestionar tu combustible, tu oxigeno, tu suministro y tu integridad de la nave para llegar a tu destino");
        Console.WriteLine("Comenzemos con el viaje entonces capitan, pulsa enter para empezar");
        Console.ReadKey();

        while (dias != 11) { // inicio ciclo de dias
            if(oxigeno < 0) // validar si el juego continua
            { 
                razon =1;
                break;
            }
            if(suministros < 0)
            {   
                razon =2;
                break;
            }
            if(combustible < 0)
            {  
                razon =3;
                break;
            }
            if (integridadNv < 0)
            {
                razon =4;
                break;
            }
            Console.WriteLine("Dia: " + dias + "\r\n Oxigeno: " + oxigeno + "\r\n Suministros: " + suministros + "\r\n Integridad: " + integridadNv + "\r\n Combustible: " + combustible);
            Task.Delay(3500).Wait();
            while (!valido) // Ciclo para validad que el dato sea numerico y este en el rango sugerido
            {
            Console.WriteLine("Elige que quieres hacer: \r\n Para empezar el dia ingresa 1 \r\n Para rendirte pulsa 2");
            string entrada = Console.ReadLine();

            if (int.TryParse(entrada, out valor))
            {
                if(valor <= 2 && valor > 0)
                {
                   valido = true;
                }
                else
                {
                    Console.WriteLine("Ingrese un numero dentro del rango solicitado");
                }
            }
            else
            {
                Console.WriteLine("Error: Ingrese un número numerico.");
            }
            }
            int op = valor;
            if (op == 2) // El usuario se rinde
            {
                Console.Clear();
                Console.WriteLine("Game over, te rendiste ;c");
                Environment.Exit(0);
            }
            if(op == 1) { // inicio de dia, muestra menu de acciones para hacer en el dia
                valor = 0;
                valido=false;
                Console.WriteLine("Hora: 8:00 am");
                Task.Delay(4000).Wait();
                while (!valido)
                {
                Console.WriteLine("Iniciemos el dia! que deseas hacer el dia de hoy: \r\n 1. Explorar un planeta \r\n 2. Reparar la nave \r\n 3. Enviar señales");
                string entrada = Console.ReadLine();

                if (int.TryParse(entrada, out valor))
                {
                    if(valor <= 3 && valor > 0)
                    {
                    valido = true;
                    }
                    else
                    {
                        Console.WriteLine("Ingrese un numero dentro del rango solicitado");
                    }
                }
                else
                {
                    Console.WriteLine("Error: Ingrese un número numerico.");
                }
                }
                int deci = valor;
                switch (deci) // Swith para las decisiones del usuario determinar que hara cada accion segun la seleccion
                {
                    case 1: // Expedicion
                        valor = 0;
                        valido = false;
                        Console.WriteLine("Iniciando expedicion... \r\n Luego de un rato : ");
                        Task.Delay(2000).Wait();
                        Console.WriteLine("Pulsa enter para ver los resultados de la expedicion");
                        Console.ReadKey();
                        combustible -= 15;
                        int probOxi = random.Next(1, 6);
                        if (probOxi <= 3)
                        {
                            int randoma = random.Next(20, 41);
                            oxigeno += randoma;
                            Console.WriteLine("Conseguiste: " + randoma + " de oxigeno");
                        }
                        int probCom = random.Next(1, 5);
                        if (probCom == 3)
                        {
                            int randoma = random.Next(10, 31);
                            combustible += randoma;
                            Console.WriteLine("Conseguiste: " + randoma + " de combustible");
                        }
                        int probSumi = random.Next(1, 3);
                        if (probSumi == 2)
                        {
                            int randoma = random.Next(30, 101);
                            suministros += randoma;
                            Console.WriteLine("Conseguiste: " + randoma + " de suministros");
                        }
                        int probTorEle = random.Next(1, 5);
                        if (probTorEle == 2)
                        {
                            int randoma = random.Next(10, 21);
                            integridadNv -= randoma;
                            Console.WriteLine("La nave sufrio daños por una Tormenta electrica del planeta");
                        }
                        int probAteFor = random.Next(1, 5);
                        if (probAteFor == 4)
                        {
                            int randoma = random.Next(10, 21);
                            integridadNv -= randoma;
                            Console.WriteLine("La nave sufrio daños. Tuvimos que hacer un aterrizaje forzoso");
                        }
                        Console.WriteLine("Acabando expedicion");
                        Console.WriteLine("Regresando a casa...");
                        Task.Delay(5000).Wait();
                        Console.WriteLine("Hora: 8:00 pm");
                        Task.Delay(5000).Wait();
                        Console.WriteLine("Resumen de expedición: \r\n Oxigeno: " + oxigeno + "\r\n Suministros: " + suministros + "\r\n Integridad: " + integridadNv + "\r\n Combustible: " + combustible);
                    break;

                    case 2: // Reparar nave
                        valor = 0;
                        valido = false;
                        Console.WriteLine("Calculando daños...");
                        Task.Delay(5000).Wait();
                        Console.WriteLine("Integridad de la nave actual: " + integridadNv);
                        Console.WriteLine("Iniciando repacion, pulsa enter");
                        Console.ReadKey();
                        int dañoNV = 100 - integridadNv;
                        if (dañoNV == 0)
                        {
                            Console.WriteLine("La nave no sufrió daños.");
                        }
                        else
                        {
                            while (!valido)
                            {
                            Console.WriteLine("Elige la acción a reparar: \r\n 1. Reparar toda la nave \r\n 2. Reparar un porcentaje de la nave ");
                            string entrada = Console.ReadLine();

                            if (int.TryParse(entrada, out valor))
                            {
                                if(valor <= 2 && valor > 0)
                                {
                                valido = true;
                                }
                                else
                                {
                                    Console.WriteLine("Ingrese un numero dentro del rango solicitado");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Error: Ingrese un valor numerico.");
                            }
                            }
                            int accion = valor;
                            if (accion == 1)
                            {
                                int costoTotal = dañoNV * 10;
                                if (costoTotal > suministros)
                                {
                                    Console.WriteLine("No tienes suficientes suministros para reparar toda la nave.");
                                }
                                else
                                {
                                    integridadNv = 100;
                                    suministros -= costoTotal;
                                    Console.WriteLine("Nave reparada al 100%. Se gastaron " + costoTotal + " unidades de suministros.");
                                }
                            }
                            else
                            {
                                valor = 0;
                                valido = false;
                                int repa;
                                int costo;

                                while (true)
                                {
                                    while (!valido)
                                    {
                                    Console.WriteLine("Ingresa el porcentaje de la nave que deseas reparar (1 a " + dañoNV + "): ");
                                    string entrada = Console.ReadLine();

                                    if (int.TryParse(entrada, out valor))
                                    {
                                        if(valor <= dañoNV && valor > 0)
                                        {
                                        valido = true;
                                        }
                                        else
                                        {
                                            Console.WriteLine("Ingrese un numero dentro del rango solicitado");
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Error: Ingrese un valor numerico.");
                                    }
                                    }
                                    repa = valor;
                                    costo = repa * 10;
                                    if (costo > suministros)
                                    {
                                        Console.WriteLine("No tienes suficientes suministros para reparar ese porcentaje. Necesitas " + costo + " unidades, pero solo tienes " + suministros + ".");
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                integridadNv += repa;
                                suministros -= costo;
                                Console.WriteLine("Estado de la nave actual " + integridadNv + "%. \r\nSe gastaron " + costo + " unidades de suministros.");
                            }
                        }
                        break;
                    case 3: // Enviar señales
                        Console.WriteLine("Enviando señales...");
                        Task.Delay(6000).Wait();
                        int opLlma = random.Next(1,3);
                        if (opLlma == 1)
                        {
                            Console.WriteLine("Gracias a las señales que enviaste recibiste ayuda!");
                            Console.WriteLine("+60 de combustible");
                            combustible += 60;
                        }
                        if (opLlma == 2)
                        {
                            Console.WriteLine("Tus señales fueron interceptadas por piratas espaciales \r\n Asaltaron tu nave...");
                            Console.WriteLine("Dañaron tu nave y te robaron suministros");
                            integridadNv -= 15;
                            suministros -= 20;
                        }
                        break;
                }

            }
            
            if(oxigeno < 0) //valida nuevamente antes de ingresar al evento y finalizar el dia si el juego continua
            { 
                razon =1;
                break;
            }
            if(suministros < 0)
            {   
                razon =2;
                break;
            }
            if(combustible < 0)
            {  
                razon =3;
                break;
            }
            if (integridadNv < 0)
            {
                razon =4;
                break;
            }
            valor=0;
            valido=false;
            Task.Delay(6000).Wait();
            int eventt = random.Next(1,8); // Determinar si habra evento
            if (eventt == 5)
            {
                int evento=random.Next(1,4);
                if (evento == 1) // Evento tormenta
                {
                    Console.WriteLine("Esta ocurriendo una tormenta electrica!!");
                    Task.Delay(3000).Wait();
                    Console.WriteLine("Estamos a salvo pero gastamos oxigeno");
                    oxigeno-=10;
                }
                if (evento == 2)// Evento Alienigenas
                {
                    Console.WriteLine("Parece que te encontraste con los chowis, una raza extraña de alienigena");
                    Console.WriteLine("Intentas hacer contacto con ellos y... ");
                    Task.Delay(3000).Wait();
                    int randoma = random.Next(1,3);
                    if (randoma == 1) 
                    {
                        Console.WriteLine("Parece que les agradaste, te dieron algo de combustible");
                        combustible+=15;
                    }
                    else{
                        Console.WriteLine("Fue un error hacer contacto, ahora te persiguen por el espacio...");
                        Task.Delay(3000).Wait();
                        Console.WriteLine("Logramos escapar por poco, pero dañaron nuestra nave.");
                        integridadNv-=10;
                    }
                    
                }
                if (evento == 3) // Evento meteoritos
                {
                    Console.WriteLine("Estan cayendo meteoritos!!");
                    Task.Delay(3000).Wait();
                    int accion = 0;
                    while (!valido)
                    {
                        Console.WriteLine("Que hacemos? \r\n 1. Maniobrar \r\n 2. Recibir el impacto");
                        string entrada = Console.ReadLine();

                        if (int.TryParse(entrada, out valor))
                        {
                            if(valor <= 2 && valor > 0)
                            {
                                valido = true;
                            }
                            else
                                {
                                    Console.WriteLine("Ingrese un numero dentro del rango solicitado");
                                }
                        }
                        else
                        {
                            Console.WriteLine("Error: Ingrese un valor numerico.");
                        }
                    }
                    accion = valor;
                    if (accion == 1) // Determina que hara el usuario. Maniobra
                    {
                        Console.WriteLine("Vamos a ver que tan capaz de maniobrar eres!");
                        Task.Delay(2000).Wait();
                        Console.WriteLine("Esquivas uno...");
                        Task.Delay(2000).Wait();
                        Console.WriteLine("Esquivas otro...");
                        Task.Delay(7000).Wait();
                        Console.WriteLine("Las maniobras fueron complicadas pero al menos estamos a salvo. Pero gastamos combustible para esquivar");
                        int randoma = random.Next(10, 31);
                        combustible-=randoma;
                    }
                    if(accion == 2)// Determina que hara el usuario. Recibe el impacto
                    {
                        Console.WriteLine("No podemos maniobrar, tendremos que recibir el impacto");
                        Task.Delay(6000).Wait();
                        Console.WriteLine("Fue un golpe fuerte, dañaron la nave");
                        int randoma = random.Next(15, 26);
                        integridadNv-=randoma;
                    }
                }
            }
            else
            {
                Console.WriteLine("El dia parece acabar tranquilo. Fue un largo dia... "); // No sucede ningun evento
            }
            //Acaba el dia, se reestablecen valores y se resta los recursos diarios. Se suma un dia más
            valor=0;
            valido=false;
            oxigeno -= 20;
            suministros -= 30;
            dias++;
        }
        if(dias == 10) // Condicion para terminar el dia
        {
            Console.WriteLine("Completaste la mision, felicidades capitan!!");
        }
        else
        { // Pierde y dice la razon por la cual perdio
            if(razon == 1){
                Console.WriteLine("Perdiste, te quedaste sin oxigeno...");
                Environment.Exit(0);
            }
            if(razon == 2){
                Console.WriteLine("Perdiste, te quedaste sin suministros...");
                Environment.Exit(0);
            }
            if(razon == 3){
                Console.WriteLine("Perdiste, te quedaste sin combustible...");
                Environment.Exit(0);
            }
            if(razon == 4){
                Console.WriteLine("Perdiste, tu nave fue destruida");
                Environment.Exit(0);
            }
        }
        
    }
}
