using System;

namespace ReservasLaboratorio
{
    public class Fecha
    {
     
     // Campos privados para almacenar los componentes de la fecha y hora

        private int dia;
        private int mes;
        private int anio;
        private int horaInicio;
        private int horaFin;

// Constructor - basicamente ayuda a inicializar la fecha o hora
        public Fecha(int d, int m, int a, int hi, int hf)
        {
            dia = d;
            mes = m;
            anio = a;
            horaInicio = hi;
            horaFin = hf;
        }

        public bool Validar()
        {
            //        // Método para validar si la fecha/hora es correcta

            // Validación básica de fecha
            if (dia < 1 || dia > 31) return false;
            if (mes < 1 || mes > 12) return false;
            if (anio < 2023) return false; // Asumimos año actual o futuro
            
            // Validación de horario
            if (horaInicio < 8 || horaInicio > 20) return false;
            if (horaFin < 8 || horaFin > 20) return false;
            if (horaInicio >= horaFin) return false;
            
            return true;
        }

        // Métodos Get
        public int GetDia() { return dia; }
        public int GetMes() { return mes; }
        public int GetAnio() { return anio; }
        public int GetHoraInicio() { return horaInicio; }
        public int GetHoraFin() { return horaFin; }
    }
}