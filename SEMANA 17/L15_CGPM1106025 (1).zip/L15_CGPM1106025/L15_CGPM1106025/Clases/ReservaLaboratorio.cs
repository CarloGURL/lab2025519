namespace ReservasLaboratorio
{
    public class ReservaLaboratorio
    {
        // Campos privados que almacenan los datos de la reserva
        private string responsable;  
        private Fecha fecha;        
        private int computadoras;   

        // Constructor - Inicializa los datos de la reserva
        public ReservaLaboratorio(string resp, Fecha f, int comp)
        {
            responsable = resp;  
            fecha = f;          
            computadoras = comp; 
        }

        // Método para validar los datos de la reserva
        public bool Validar()
        {
            // Verifica:
            // 1. Que la fecha/horario sean válidos (usando el método Validar() de Fecha)
            // 2. Que la cantidad de computadoras esté entre 1 y 40
            return fecha.Validar() && computadoras >= 1 && computadoras <= 40;
        }

        // Método para mostrar los detalles de la reserva
        public void Mostrar()
        {
            Console.WriteLine("Responsable: " + responsable);  
            
            Console.WriteLine("Fecha: " + fecha.GetDia() + "/" + fecha.GetMes() + "/" + fecha.GetAnio());
            
            Console.WriteLine("Horario: " + fecha.GetHoraInicio() + " - " + fecha.GetHoraFin());
            Console.WriteLine("Computadoras: " + computadoras); 
            Console.WriteLine("-----------------------");       
        }

        // Métodos GETTERS para acceder a los campos privados:

        public string GetResponsable() 
        { 
            return responsable;  
        }

        public Fecha GetFecha() 
        { 
            return fecha;  
        }

        public int GetComputadoras() 
        { 
            return computadoras;  
        }
    }
}