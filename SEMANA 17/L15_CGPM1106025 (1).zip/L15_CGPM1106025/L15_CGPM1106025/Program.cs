﻿using System;

namespace ReservasLaboratorio
{
    class Program
    {
        static ReservaLaboratorio[] reservas = new ReservaLaboratorio[50];
        static int totalReservas = 0;

        static void Main(string[] args)
        {
            bool salir = false;
            
            while(!salir)
            {
                Console.WriteLine("\nMENU PRINCIPAL");
                Console.WriteLine("1. Agregar reserva");
                Console.WriteLine("2. Ver reservas");
                Console.WriteLine("3. Buscar por responsable");
                Console.WriteLine("4. Salir");
                Console.Write("Elija: ");
                
                string opcion = Console.ReadLine();
                // Controlar la opción seleccionada

                if(opcion == "1") AgregarReserva();
                else if(opcion == "2") MostrarReservas();
                else if(opcion == "3") BuscarResponsable();
                else if(opcion == "4") salir = true;
                else Console.WriteLine("Opcion no valida");
            }
        }
        // Método para agregar una nueva reserva

        static void AgregarReserva()
        {
                        // Verificar si hay espacio para más reservas

            if(totalReservas >= 50)
            {
                Console.WriteLine("Maximo de reservas alcanzado");
                return;
            }
//En todos estos writeline de abajo basicamente es verificar cada uno de los datos para alimentar la base de datos
//continuare aqui: en este caso usamos el nombre de responsable, fecha, hora, no de compus, etc 
//todo esto para ordenar los datos y que se entienda de mejor manera
            Console.Write("\nNombre responsable: ");
            string responsable = Console.ReadLine();

            Console.Write("Dia (1-31): ");
            string diaStr = Console.ReadLine();
            if(!EsNumero(diaStr)) { Console.WriteLine("Dia debe ser numero"); return; }
            int dia = int.Parse(diaStr);

            Console.Write("Mes (1-12): ");
            string mesStr = Console.ReadLine();
            if(!EsNumero(mesStr)) { Console.WriteLine("Mes debe ser numero"); return; }
            int mes = int.Parse(mesStr);

            Console.Write("Año: ");
            string anioStr = Console.ReadLine();
            if(!EsNumero(anioStr)) { Console.WriteLine("Año debe ser numero"); return; }
            int anio = int.Parse(anioStr);

            Console.Write("Hora inicio (8-20): ");
            string hiStr = Console.ReadLine();
            if(!EsNumero(hiStr)) { Console.WriteLine("Hora debe ser numero"); return; }
            int hi = int.Parse(hiStr);

            Console.Write("Hora fin (8-20): ");
            string hfStr = Console.ReadLine();
            if(!EsNumero(hfStr)) { Console.WriteLine("Hora debe ser numero"); return; }
            int hf = int.Parse(hfStr);

            Console.Write("Computadoras (1-40): ");
            string compStr = Console.ReadLine();
            if(!EsNumero(compStr)) { Console.WriteLine("Cantidad debe ser numero"); return; }
            int comp = int.Parse(compStr);

            Fecha nuevaFecha = new Fecha(dia, mes, anio, hi, hf);
            ReservaLaboratorio nueva = new ReservaLaboratorio(responsable, nuevaFecha, comp);

// Validar la reserva antes de agregarla
            if(ValidarReserva(nueva))
            {
                reservas[totalReservas] = nueva;
                totalReservas++;
                Console.WriteLine("Reserva agregada");
            }
            else
            {
                Console.WriteLine("Datos no validos");
            }
        }

        static bool EsNumero(string valor)
        {
            foreach(char c in valor)
            {
                if(!char.IsDigit(c)) return false;
            }
            return valor.Length > 0;
        }
        // Validar los datos de la reserva y verificar disponibilidad

        static bool ValidarReserva(ReservaLaboratorio r)
        {
            if(!r.Validar()) return false;

            for(int i = 0; i < totalReservas; i++)
            {
                Fecha existente = reservas[i].GetFecha();
                Fecha nueva = r.GetFecha();

                if(existente.GetDia() == nueva.GetDia() && 
                   existente.GetMes() == nueva.GetMes() && 
                   existente.GetAnio() == nueva.GetAnio())
                {
                    if(nueva.GetHoraInicio() < existente.GetHoraFin() && 
                       nueva.GetHoraFin() > existente.GetHoraInicio())
                    {
                        Console.WriteLine("Horario ocupado");
                        return false;
                    }
                }
            }
            return true;
        } 

        static void MostrarReservas()
        {
            if(totalReservas == 0)
            {
                Console.WriteLine("No hay reservas");
                return;
            }

            // Ordenar las reservas por fecha
            for(int i = 0; i < totalReservas-1; i++)
            {
                for(int j = i+1; j < totalReservas; j++)
                {
                    if(CompararFechas(reservas[i].GetFecha(), reservas[j].GetFecha()) > 0)
                    {
                        ReservaLaboratorio temp = reservas[i];
                        reservas[i] = reservas[j];
                        reservas[j] = temp;
                    }
                }
            }

            // Mostrar todas las reservas ordenadas

            Console.WriteLine("\nLISTA DE RESERVAS:");
            for(int i = 0; i < totalReservas; i++)
            {
                Console.WriteLine("\nReserva " + (i+1));
                reservas[i].Mostrar();
            }
        }

        // Comparar dos fechas para determinar su orden

        static int CompararFechas(Fecha a, Fecha b)
        {
            if(a.GetAnio() != b.GetAnio()) return a.GetAnio() - b.GetAnio();
            if(a.GetMes() != b.GetMes()) return a.GetMes() - b.GetMes();
            return a.GetDia() - b.GetDia();
        }

        // Buscar reservas por nombre de responsable

        static void BuscarResponsable()
        {
            Console.Write("\nNombre a buscar: ");
            string nombre = Console.ReadLine().ToLower();
            bool encontrado = false;

            for(int i = 0; i < totalReservas; i++)
            {
                if(reservas[i].GetResponsable().ToLower().Contains(nombre))
                {
                    reservas[i].Mostrar();
                    encontrado = true;
                }
            }

            if(!encontrado) Console.WriteLine("No se encontraron reservas");
        }
    }
}